#include <windows.h>

BOOL WINAPI DllMain(HINSTANCE hinstDLL,  // DLL module handler
                    DWORD fdwReason,     // reason of call function
                    LPVOID lpvReserved   // reserve argument
) {
    return TRUE;
}
