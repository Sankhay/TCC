# GIFT-64

Created GIFT-64 based on paper https://eprint.iacr.org/2017/622.pdf. 
One can find more information on https://giftcipher.github.io/gift/ 
However, is tested on the vector test from the source code in https://github.com/giftcipher/gift.
