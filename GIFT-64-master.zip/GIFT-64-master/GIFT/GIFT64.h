#ifndef _GIFT64_H
#define _GIFT64_H
#include <inttypes.h>


uint64_t GIFT64_Encryption(uint64_t, uint16_t*);
uint64_t GIFT64_Decryption(uint64_t, uint16_t*);

#endif	
